Author:

- `Dan Foreman-Mackey (NYU) <https://github.com/dfm>`_

Direct contributions to the code base:

- `Ruth Angus <https://github.com/RuthAngus>`_
- `Bence Béky <https://github.com/bencebeky>`_
- `Frederik Beaujean <https://github.com/fredRos>`_
- `Alex Conley <https://github.com/aconley>`_
- `Miguel de Val-Borro <https://github.com/migueldvb>`_
- `Will Meierjurgen Farr <https://github.com/farr>`_
- `Júlio Hoffimann Mendes <https://github.com/juliohm>`_
- `David W. Hogg <https://github.com/davidwhogg>`_
- `Dustin Lang <https://github.com/dstndstn>`_
- `Phil Marshall <https://github.com/drphilmarshall>`_
- `Demitri Muna <https://github.com/demitri>`_
- `Adrian Price-Whelan <https://github.com/adrn>`_
- `Jeremy Sanders <https://github.com/jeremysanders>`_
- `Leo Singer <https://github.com/lpsinger>`_
- `Manodeep Sinha <https://bitbucket.org/manodeep/>`_
- `Marco Tazzari <https://github.com/mtazzari>`_
- `Erik Tollerud <https://github.com/eteq>`_
- `Simon Walker <https://github.com/mindriot101>`_
- `Peter K. G. Williams <https://github.com/pkgw>`_
- `Joe Zuntz <https://github.com/joezuntz>`_

Comments, corrections & suggestions:

- Eric Agol
- Jo Bovy
- Andrew Bradshaw
- Jacqueline Chen
- John Gizis
- Jonathan Goodman
- Jennifer Piscionere
